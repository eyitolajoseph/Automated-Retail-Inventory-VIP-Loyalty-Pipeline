clear;
clc;
close all;

% Step 1: Define initial store budget and customer purchase records
initialBudget = 5000;
customerPurchases = [1200, 300, 650, 150, 2100];

% Step 2: Define current stock levels per product and reorder threshold
productStock = [15, 3, 40, 2, 8];
restockThreshold = 5;

% Step 3: Run the loyalty engine function
customerTiers = loyaltyEngine(customerPurchases);

% Step 4: Run the stock checking function
needsRestock = checkStock(productStock, restockThreshold);

% Step 5: Simulate budget spend-down dynamics
totalSales = sum(customerPurchases);
remainingBudget = initialBudget - totalSales;

% Step 6: Display customer loyalty tiers
disp('================ CUSTOMER LOYALTY TIERS ================');

for i = 1:length(customerPurchases)
    disp(['Customer ', num2str(i), ...
        ' Spend: $', num2str(customerPurchases(i)), ...
        ' -> Tier: ', customerTiers(i)]);
end

% Step 7: Display inventory status and restock alerts
disp(' ');
disp('================ INVENTORY & RESTOCK ALERTS ============');

for j = 1:length(productStock)

    if needsRestock(j) == 1
        disp(['Product SKU #', num2str(j), ...
            ': Stock = ', num2str(productStock(j)), ...
            ' units -> [ALERT: RESTOCK NEEDED]']);
    else
        disp(['Product SKU #', num2str(j), ...
            ': Stock = ', num2str(productStock(j)), ...
            ' units -> [STATUS: OK]']);
    end

end

% Step 8: Display budget spend-down summary
disp(' ');
disp('================ FINANCIAL SUMMARY =====================');

disp(['Starting Store Budget: $', num2str(initialBudget)]);
disp(['Total Sales Processed: $', num2str(totalSales)]);
disp(['Remaining Net Balance: $', num2str(remainingBudget)]);

%[appendix]{"version":"1.0"}
%---
%[metadata:view]
%   data: {"layout":"onright"}
%---

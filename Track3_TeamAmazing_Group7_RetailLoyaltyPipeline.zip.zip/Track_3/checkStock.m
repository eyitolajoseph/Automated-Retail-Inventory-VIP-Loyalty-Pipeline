function restockNeeded = checkStock(stockVector, minLimit)
% stockVector: 1D array containing available unit counts for each item
% minLimit: the minimum quantity threshold before reordering is triggered

restockNeeded = stockVector <= minLimit;

end

%[appendix]{"version":"1.0"}
%---

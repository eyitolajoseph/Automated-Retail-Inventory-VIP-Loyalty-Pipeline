function customerTiers = loyaltyEngine(customerPurchases)

customerTiers = strings(size(customerPurchases));

for i = 1:length(customerPurchases)

    if customerPurchases(i) < 500
        customerTiers(i) = "Bronze";

    elseif customerPurchases(i) < 1000
        customerTiers(i) = "Silver";

    elseif customerPurchases(i) < 2000
        customerTiers(i) = "Gold";

    else
        customerTiers(i) = "Platinum";
    end

end

end

%[appendix]{"version":"1.0"}
%---
